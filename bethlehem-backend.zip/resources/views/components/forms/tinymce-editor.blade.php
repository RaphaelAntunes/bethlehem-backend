<form method="post">
    <textarea id="myeditorinstance"></textarea>
  </form>