<footer class="footer footer-black  footer-white ">
 
</footer><?php /**PATH C:\Users\Phael\Desktop\Projeto-Igreja\bethlehem-backend\resources\views/layouts/footer.blade.php ENDPATH**/ ?>