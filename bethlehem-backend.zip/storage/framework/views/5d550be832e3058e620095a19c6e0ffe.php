<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="col-lg-4 col-md-8 ml-auto mr-auto">
                <form class="form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card card-login">
                        <div class="card-header ">
                            <div class="card-header d-flex flex-column justify-content-center align-items-center ">
                                <img src="/paper/img/logo-ib.png" alt="">
                                <h3 class="header text-center mt-3"><?php echo e(__('Sistema IBB')); ?></h3>
                            </div>
                        </div>
                        <div class="card-body" style="min-height: 100px;">

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i style="font-size:18px;" class="nc-icon nc-single-02"></i>
                                    </span>
                                </div>
                                <input style="padding:20px;" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('E-mail')); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i style="font-size:18px;" class="nc-icon nc-lock-circle-open"></i>
                                    </span>
                                </div>
                                <input style="padding:20px;" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Senha')); ?>" type="password" required>
                                
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <div class="form-check">
                                     <label class="form-check-label">
                                        <input class="form-check-input" name="remember" type="checkbox" value="" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <span class="form-check-sign"></span>
                                        <?php echo e(__('Lembrar o acesso')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <div class="text-center">
                                <button style="width: 100%;max-width: 138px;height: 100%;min-height: 39px;font-size: 15px;" type="submit" class="btn btn-warning btn-round mb-3"><?php echo e(__('Entrar')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            demo.checkFullPageBackgroundImage();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
    'class' => 'login-page',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phael\Desktop\Projeto-Igreja\bethlehem-backend\resources\views/auth/login.blade.php ENDPATH**/ ?>