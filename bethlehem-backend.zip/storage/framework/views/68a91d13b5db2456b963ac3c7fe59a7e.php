<form method="post">
    <textarea id="myeditorinstance"></textarea>
  </form><?php /**PATH C:\Users\Phael\Desktop\Projeto-Igreja\bethlehem-backend\resources\views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>