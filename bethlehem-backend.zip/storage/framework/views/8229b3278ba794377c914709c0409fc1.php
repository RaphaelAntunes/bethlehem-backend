<?php echo $__env->make('pages.new-evento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid mt--7">
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-1">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h3 class="mb-0">Eventos</h3>
                                    <hr>
                                </div>
                                <div class="col-md-4 text-right">
                                    <a href="#" class="btn btn-sm btn-primary" onclick="abrirModal()">Adicionar</a>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-4">
                                    <div class="card card-event">
                                        <div class="card-body">

                                            <form method="post"
                                                action="<?php echo e($evento->estaParticipando($evento->id) ? route('remover-presenca') : route('marcar-presenca')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="evento_id" value="<?php echo e($evento->id); ?>">

                                                <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                                <input type="hidden" name="marcado"
                                                    value="<?php echo e($evento->estaParticipando(auth()->user()->id) ? 0 : 1); ?>">
                                                <div style="justify-content:right;" class="d-flex aling-items-right">

                                                        <span style="cursor:pointer; font-size: 20px;"onclick="removerEvento(<?php echo e($evento->id); ?>)" data-notify="icon" style="margin-right: 0px; font-size: 20px;"
                                                            class="nc-icon nc-simple-remove"></span>
                                                </div>
                                                <span data-notify="icon" class="nc-icon nc-istanbul mb-1"></span>
                                                <h5 class="card-title"><?php echo e($evento->titulo); ?></h5>
                                                <?php
                                                    // Consulta para obter o nome do mediador com base no ID
                                                    $mediador = App\Models\getMediadores::find($evento->mediador);
                                                    $mediador = json_decode($mediador);
                                                ?>
                                                <?php if($mediador): ?>
                                                    <h6 class="card-subtitle mb-2 text-muted">Por: <?php echo e($mediador->name); ?>

                                                    </h6>
                                                <?php endif; ?>
                                                <hr>
                                                <p class="card-text"><?php echo e($evento->descricao); ?></p>
                                                <!-- Botão para marcar ou cancelar a presença -->
                                                <button type="submit"
                                                    class="btn btn-sm <?php echo e($evento->estaParticipando($evento->id) ? 'btn-danger' : 'btn-primary'); ?>">
                                                    <?php echo e($evento->estaParticipando($evento->id) ? 'Cancelar Presença' : 'Marcar Presenças'); ?>

                                                </button>
                                                <i
                                                    class="nc-icon nc-single-02 ml-2"><?php echo e($evento->numparticipantes($evento->id)); ?></i>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
       

        function removerEvento(eventoId) {
            var token = $('input[name="_token"]').val();
            if (confirm('Tem certeza de que deseja remover este evento?')) {
            $.ajax({
                url: '/remover-evento/' + eventoId,
                type: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': token // Inclua o token CSRF no cabeçalho da requisição
                },
                success: function(response) {
                    window.location.reload();

                },
                error: function(error) {
                    window.location.reload();

                }
            });
        }}
    </script>

<?php echo $__env->make('layouts.app', [
    'class' => '',
    'elementActive' => 'eventos',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phael\Desktop\Projeto-Igreja\bethlehem-backend\resources\views/pages/eventos.blade.php ENDPATH**/ ?>