<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
      
            <div class="mb-2">
                <img src="<?php echo e(asset('paper')); ?>/img/logo-ib.png">
            </div>
     
           <p class="txt-logo">Igreja<br>Batista<br>Bethleem</p>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <!--
            <li class="<?php echo e($elementActive == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'dashboard')); ?>">
                    <i class="nc-icon nc-bank"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
        -->
            <li class="<?php echo e($elementActive == 'user' || $elementActive == 'profile' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="true" href="#laravelExamples">
                    <i class="nc-icon nc-settings"></i>

                    <p>
                            <?php echo e(__('FERRAMENTAS')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExamples">
                    <ul class="nav ml-3">
                        <li class="<?php echo e($elementActive == 'user' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'user')); ?>">
                                <i class="nc-icon nc-single-02"></i>
                                <p><?php echo e(__('GERENCIAR MEMBROS')); ?></p>
                            </a>
                        </li>
                         <li class="<?php echo e($elementActive == 'email' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'email')); ?>">
                                <i class="nc-icon nc-email-85"></i>
                                <p><?php echo e(__('Enviar E-mail')); ?></p>
                            </a>
                        </li>
                          <!--
                        <li class="<?php echo e($elementActive == 'eventos' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'eventos')); ?>">
                                <i class="nc-icon nc-istanbul"></i>
                                <p><?php echo e(__('GERENCIAR EVENTOS')); ?></p>
                            </a>
                        </li> -->
                    </ul>
                </div>
            </li>
           
        </li>

        <hr>
        <!--
        <li class="<?php echo e($elementActive == 'icons' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('page.index', 'icons')); ?>">
                <i class="nc-icon nc-diamond"></i>
                <p><?php echo e(__('Icons')); ?></p>
            </a>
        </li>
            <li class="<?php echo e($elementActive == 'map' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'map')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p><?php echo e(__('Maps')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'notifications' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'notifications')); ?>">
                    <i class="nc-icon nc-bell-55"></i>
                    <p><?php echo e(__('Notifications')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'tables' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'tables')); ?>">
                    <i class="nc-icon nc-tile-56"></i>
                    <p><?php echo e(__('Table List')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'typography' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'typography')); ?>">
                    <i class="nc-icon nc-caps-small"></i>
                    <p><?php echo e(__('Typography')); ?></p>
                </a>
            </li>

        -->
           
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Phael\Desktop\Projeto-Igreja\bethlehem-backend\resources\views/layouts/navbars/auth.blade.php ENDPATH**/ ?>